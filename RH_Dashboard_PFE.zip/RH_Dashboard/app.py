
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime

st.set_page_config(page_title="RH Dashboard - La Pratique Electronique", page_icon="📊", layout="wide")

st.markdown("""
<style>
.big-metric { font-size: 32px; font-weight: bold; color: #1f77b4; }
.header { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); padding: 20px; border-radius: 10px; color: white; text-align: center; margin-bottom: 20px; }
.metric-card { background-color: #f0f2f6; padding: 15px; border-radius: 10px; text-align: center; }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    effectifs = pd.read_csv('data/effectifs.csv')
    mouvements = pd.read_csv('data/mouvements.csv')
    promotions = pd.read_csv('data/promotions.csv')
    questionnaires = pd.read_csv('data/questionnaires.csv')
    entretiens = pd.read_csv('data/entretiens.csv')
    sanctions = pd.read_csv('data/sanctions.csv')
    
    effectifs['Date_Embauche'] = pd.to_datetime(effectifs['Date_Embauche'])
    effectifs['Date_Sortie'] = pd.to_datetime(effectifs['Date_Sortie'], errors='coerce')
    mouvements['Mois'] = pd.to_datetime(mouvements['Mois'])
    promotions['Date_Promot'] = pd.to_datetime(promotions['Date_Promot'])
    
    return effectifs, mouvements, promotions, questionnaires, entretiens, sanctions

effectifs, mouvements, promotions, questionnaires, entretiens, sanctions = load_data()

actifs = effectifs[effectifs['Date_Sortie'].isna()]
total = len(actifs)
departs = len(effectifs[~effectifs['Date_Sortie'].isna()])
turnover = (departs / len(effectifs) * 100) if len(effectifs) > 0 else 0

cadres = effectifs[effectifs['Categorie'] == 'Cadre']
fuite_cadres = (len(cadres[~cadres['Date_Sortie'].isna()]) / len(cadres) * 100) if len(cadres) > 0 else 0

recents = effectifs[effectifs['Date_Embauche'] > datetime.now() - pd.Timedelta(days=365)]
qualite = (len(recents[recents['Date_Sortie'].isna()]) / len(recents) * 100) if len(recents) > 0 else 0

st.sidebar.title("📊 Tableau de Bord RH")
st.sidebar.markdown("### La Pratique Electronique")
st.sidebar.markdown("**Présenté par:** Souha Ferjani")
st.sidebar.markdown("**Projet PFE - Business Intelligence**")
st.sidebar.markdown("---")

page = st.sidebar.radio("Navigation", ["🏠 Accueil", "📈 Effectifs", "🔄 Mouvements", "⭐ Promotions", "📋 Admin", "🎯 Stratégique", "⚠️ Alertes"])
st.sidebar.markdown("---")
st.sidebar.caption("© 2025 - Projet PFE")

if page == "🏠 Accueil":
    st.markdown('<div class="header"><h1>📊 Tableau de Bord RH</h1><p>La Pratique Electronique</p></div>', unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("👥 Effectif Total", total)
        st.markdown('</div>', unsafe_allow_html=True)
    with col2:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("📈 Taux de Rotation", f"{turnover:.1f}%")
        st.markdown('</div>', unsafe_allow_html=True)
    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("⭐ Promotions", len(promotions))
        st.markdown('</div>', unsafe_allow_html=True)
    with col4:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("🚪 Départs", departs)
        st.markdown('</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        effectifs_service = actifs.groupby('Service').size().reset_index(name='Effectif')
        fig = px.pie(effectifs_service, values='Effectif', names='Service', title="Répartition par Service")
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        effectifs_cat = actifs.groupby('Categorie').size().reset_index(name='Effectif')
        fig = px.bar(effectifs_cat, x='Categorie', y='Effectif', title="Cadres vs Non-cadres", color='Categorie')
        st.plotly_chart(fig, use_container_width=True)

elif page == "📈 Effectifs":
    st.header("📈 Analyse des Effectifs")
    col1, col2 = st.columns(2)
    with col1:
        service = st.selectbox("Filtrer par Service", actifs['Service'].unique())
        st.dataframe(actifs[actifs['Service'] == service][['Matricule', 'Categorie', 'Sexe']], use_container_width=True)
    with col2:
        fig = px.histogram(actifs, x='Service', title="Distribution par service", color='Categorie')
        st.plotly_chart(fig, use_container_width=True)

elif page == "🔄 Mouvements":
    st.header("🔄 Mouvements du Personnel")
    mouvements['Total_Sorties'] = mouvements['Sorties_Dem'] + mouvements['Sorties_Retr'] + mouvements['Sorties_Lice']
    
    fig = go.Figure()
    fig.add_trace(go.Bar(x=mouvements['Mois'].dt.strftime('%b %Y'), y=mouvements['Entrees'], name='Entrées', marker_color='green'))
    fig.add_trace(go.Bar(x=mouvements['Mois'].dt.strftime('%b %Y'), y=mouvements['Total_Sorties'], name='Sorties', marker_color='red'))
    fig.update_layout(title='Entrées vs Sorties mensuelles', barmode='group')
    st.plotly_chart(fig, use_container_width=True)
    
    motifs = {
        'Démission': mouvements['Sorties_Dem'].sum(),
        'Retraite': mouvements['Sorties_Retr'].sum(),
        'Licenciement': mouvements['Sorties_Lice'].sum()
    }
    df_motifs = pd.DataFrame(list(motifs.items()), columns=['Motif', 'Nombre'])
    fig = px.pie(df_motifs, values='Nombre', names='Motif', title="Motifs de sortie")
    st.plotly_chart(fig, use_container_width=True)
    
    col1, col2, col3 = st.columns(3)
    with col1: st.metric("Total Entrées", mouvements['Entrees'].sum())
    with col2: st.metric("Total Sorties", mouvements['Total_Sorties'].sum())
    with col3: st.metric("Taux Rotation", f"{turnover:.1f}%")

elif page == "⭐ Promotions":
    st.header("⭐ Promotions Internes")
    st.dataframe(promotions, use_container_width=True)
    if len(promotions) > 0:
        promotions_par_annee = promotions.groupby(promotions['Date_Promot'].dt.year).size().reset_index(name='Nombre')
        promotions_par_annee.columns = ['Année', 'Nombre']
        fig = px.bar(promotions_par_annee, x='Année', y='Nombre', title="Promotions par année")
        st.plotly_chart(fig, use_container_width=True)

elif page == "📋 Admin":
    st.header("📋 Gestion Administrative")
    col1, col2 = st.columns(2)
    with col1:
        fig = px.line(questionnaires, x='Periode', y='Taux_Reponse', title="Taux de réponse aux questionnaires", markers=True)
        fig.add_hline(y=50, line_dash="dash", line_color="red", annotation_text="Seuil (50%)")
        st.plotly_chart(fig, use_container_width=True)
    with col2:
        fig = px.bar(entretiens, x='Annee', y='Taux_Realisation', title="Entretiens annuels", text='Taux_Realisation')
        fig.add_hline(y=80, line_dash="dash", line_color="red", annotation_text="Objectif (80%)")
        st.plotly_chart(fig, use_container_width=True)
    st.subheader("⚖️ Sanctions disciplinaires")
    st.dataframe(sanctions, use_container_width=True)

elif page == "🎯 Stratégique":
    st.header("🎯 Indicateurs Stratégiques")
    col1, col2 = st.columns(2)
    with col1:
        st.metric("✅ Qualité des recrutements", f"{qualite:.1f}%")
        st.progress(qualite/100)
    with col2:
        st.metric("💨 Fuite des compétences", f"{fuite_cadres:.1f}%")
        st.progress(fuite_cadres/100)
    
    st.subheader("🎯 Score de risque par service")
    risques = []
    for s in actifs['Service'].unique():
        effectif = len(actifs[actifs['Service'] == s])
        departs_s = len(effectifs[(effectifs['Service'] == s) & (~effectifs['Date_Sortie'].isna())])
        turnover_s = (departs_s / effectif * 100) if effectif > 0 else 0
        niveau = "🟢 Faible" if turnover_s < 10 else "🟡 Moyen" if turnover_s < 20 else "🔴 Élevé"
        risques.append({'Service': s, 'Turnover': round(turnover_s, 1), 'Niveau': niveau})
    st.dataframe(pd.DataFrame(risques), use_container_width=True)

elif page == "⚠️ Alertes":
    st.header("⚠️ Alertes Automatiques")
    alertes = []
    if turnover > 15: alertes.append(("🔴 CRITIQUE", f"Turnover élevé: {turnover:.1f}%"))
    if fuite_cadres > 10: alertes.append(("🔴 CRITIQUE", f"Fuite des cadres: {fuite_cadres:.1f}%"))
    if qualite < 80: alertes.append(("🟡 ATTENTION", f"Qualité recrutements: {qualite:.1f}%"))
    if entretiens['Taux_Realisation'].iloc[-1] < 80: alertes.append(("🟡 ATTENTION", f"Entretiens annuels: {entretiens['Taux_Realisation'].iloc[-1]}%"))
    
    if alertes:
        for type_alerte, message in alertes:
            if "🔴" in type_alerte:
                st.error(f"{type_alerte} | {message}")
            else:
                st.warning(f"{type_alerte} | {message}")
    else:
        st.success("✅ Aucune alerte critique détectée")
    
    st.markdown("---")
    st.subheader("📋 Recommandations")
    if turnover > 15: st.write("• Mettre en place un plan de rétention des talents")
    if fuite_cadres > 10: st.write("• Organiser des entretiens de départ avec les cadres")
    if qualite < 80: st.write("• Renforcer le programme d'intégration des nouveaux employés")

st.markdown("---")
st.caption("📊 La Pratique Electronique | Projet PFE - Souha Ferjani | Business Intelligence")
