# RH Dashboard - La Pratique Electronique

## Projet PFE - Souha Ferjani
Tableau de bord RH interactif

### Fonctionnalités
- Effectifs par service
- Mouvements et turnover
- Promotions internes
- Gestion administrative
- Indicateurs stratégiques
- Alertes automatiques

### Installation
```bash
pip install -r requirements.txt
streamlit run app.py
```

### Lien public
https://username-rh-dashboard.streamlit.app
