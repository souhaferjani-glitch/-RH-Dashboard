
import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="RH Dashboard", layout="wide")
st.title("📊 Tableau de Bord RH")
st.markdown("### La Pratique Electronique - Souha Ferjani")

# Données
df = pd.DataFrame({
    'Matricule': ['EMP001', 'EMP002', 'EMP003', 'EMP004', 'EMP005'],
    'Service': ['Commercial', 'RH', 'Technique', 'Commercial', 'RH'],
    'Categorie': ['Cadre', 'Non cadre', 'Cadre', 'Non cadre', 'Cadre']
})

mouvements = pd.DataFrame({
    'Mois': ['Jan', 'Fév', 'Mar', 'Avr', 'Mai'],
    'Entrees': [2, 1, 3, 0, 2],
    'Sorties': [1, 1, 2, 1, 0]
})

# Sidebar
page = st.sidebar.radio("Navigation", ["Accueil", "Effectifs", "Mouvements"])

if page == "Accueil":
    col1, col2 = st.columns(2)
    with col1: st.metric("👥 Effectif", len(df))
    with col2: st.metric("📈 Turnover", "12%")
    fig = px.pie(df, names='Service', title="Effectifs par Service")
    st.plotly_chart(fig)

elif page == "Effectifs":
    st.dataframe(df)
    fig = px.bar(df, x='Service', title="Effectifs par Service")
    st.plotly_chart(fig)

elif page == "Mouvements":
    fig = px.bar(mouvements, x='Mois', y=['Entrees', 'Sorties'], barmode='group')
    st.plotly_chart(fig)
